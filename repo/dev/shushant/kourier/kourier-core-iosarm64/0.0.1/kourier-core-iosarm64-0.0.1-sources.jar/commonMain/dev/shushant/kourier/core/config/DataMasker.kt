package dev.shushant.kourier.core.config

import dev.shushant.kourier.core.model.HttpHeader

class DataMasker(
    val maskedHeaders: Set<String> = DEFAULT_MASKED_HEADERS,
    val maskedPayloadKeys: Set<String> = DEFAULT_MASKED_KEYS,
    val maskedQueryParams: Set<String> = DEFAULT_MASKED_QUERY_PARAMS,
    val replacementMask: String = "••••••••"
) {
    companion object {
        val DEFAULT_MASKED_HEADERS = setOf(
            "authorization",
            "proxy-authorization",
            "cookie",
            "set-cookie",
            "x-auth-token",
            "x-api-key",
            "api-key",
            "session-token",
            "bearer"
        )

        val DEFAULT_MASKED_KEYS = setOf(
            "password",
            "pass",
            "token",
            "access_token",
            "refresh_token",
            "secret",
            "client_secret",
            "api_key",
            "apikey",
            "private_key",
            "ssn",
            "social_security",
            "credit_card",
            "card_number",
            "cvv",
            "pin",
            "auth_code"
        )

        val DEFAULT_MASKED_QUERY_PARAMS = setOf(
            "token",
            "access_token",
            "apiKey",
            "api_key",
            "secret",
            "password"
        )
    }

    /** Mask a list of headers based on configuration. */
    fun maskHeaders(headers: List<Pair<String, String>>): List<HttpHeader> {
        return headers.map { (name, value) ->
            val shouldMask = maskedHeaders.any { it.equals(name.trim(), ignoreCase = true) }
            HttpHeader(
                name = name,
                value = if (shouldMask) replacementMask else value,
                isRedacted = shouldMask
            )
        }
    }

    /** Redact query parameters inside a full URL. */
    fun maskUrl(url: String): String {
        if (!url.contains("?") || maskedQueryParams.isEmpty()) return url

        val baseUrl = url.substringBefore("?")
        val queryString = url.substringAfter("?")

        val maskedQuery = queryString.split("&").joinToString("&") { param ->
            val parts = param.split("=", limit = 2)
            val key = parts[0]
            val value = if (parts.size > 1) parts[1] else ""

            val shouldMask = maskedQueryParams.any { it.equals(key.trim(), ignoreCase = true) }
            if (shouldMask) "$key=$replacementMask" else param
        }

        return "$baseUrl?$maskedQuery"
    }

    /**
     * Redacts JSON payload keys recursively using regex matching.
     * Matches patterns like:
     * "password": "value" -> "password": "••••••••"
     * "password": 12345 -> "password": "••••••••"
     */
    fun maskPayload(payload: String?): String? {
        if (payload.isNullOrBlank() || maskedPayloadKeys.isEmpty()) return payload

        var currentText: String = payload
        for (key in maskedPayloadKeys) {
            val escapedKey = Regex.escape(key)
            // Match JSON key with string value: "key"\s*:\s*"([^"]*)"
            val stringPattern = Regex("""("(?i)$escapedKey"\s*:\s*")([^"]*)(")""")
            currentText = stringPattern.replace(currentText) { matchResult: MatchResult ->
                "${matchResult.groupValues[1]}$replacementMask${matchResult.groupValues[3]}"
            }

            // Match JSON key with number or boolean: "key"\s*:\s*([0-9a-zA-Z._-]+)
            val nonStringPattern = Regex("""("(?i)$escapedKey"\s*:\s*)([0-9a-zA-Z._-]+)""")
            currentText = nonStringPattern.replace(currentText) { matchResult: MatchResult ->
                "${matchResult.groupValues[1]}\"$replacementMask\""
            }
        }
        return currentText
    }
}
