package dev.shushant.kourier.ui

import android.content.Intent
import dev.shushant.kourier.core.KourierCore
import dev.shushant.kourier.ui.activity.KourierActivity
import dev.shushant.kourier.ui.export.AndroidContextHolder
import dev.shushant.kourier.ui.triggers.NotificationTrigger
import dev.shushant.kourier.ui.triggers.ShakeDetector
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.launch
import kotlin.time.Duration.Companion.milliseconds

actual object KourierUI {
    private var shakeDetector: ShakeDetector? = null
    private var notificationScope: CoroutineScope? = null

    actual fun show() {
        val context = AndroidContextHolder.currentActivity ?: AndroidContextHolder.applicationContext ?: return
        val intent = Intent(context, KourierActivity::class.java).apply {
            if (context !is android.app.Activity) {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
        }
        context.startActivity(intent)
    }

    actual fun hide() {
        (AndroidContextHolder.currentActivity as? KourierActivity)?.finish()
    }

    @OptIn(FlowPreview::class)
    actual fun startTriggers() {
        // Guard against double-start (e.g. Activity recreate without stopTriggers).
        if (notificationScope != null) return

        val config = KourierCore.config
        if (config.enableShakeGesture) {
            shakeDetector = ShakeDetector().apply {
                start { show() }
            }
        }
        if (config.enableNotification) {
            val scope = CoroutineScope(Dispatchers.Default + Job())
            notificationScope = scope
            scope.launch {
                // Debounce rapid bursts (e.g. 93 requests in quick succession) so
                // Android's NotificationManager is not rate-limited into dropping updates.
                // 500 ms trailing edge: the notification refreshes at most twice per second
                // and always reflects the latest state after a burst settles.
                KourierCore.eventBus.telemetry
                    .debounce(500L.milliseconds)
                    .collect { telemetry ->
                        NotificationTrigger.updateNotification(telemetry)
                    }
            }
        }
    }

    actual fun stopTriggers() {
        shakeDetector?.stop()
        shakeDetector = null
        notificationScope?.cancel()
        notificationScope = null
        NotificationTrigger.dismiss()
    }
}
