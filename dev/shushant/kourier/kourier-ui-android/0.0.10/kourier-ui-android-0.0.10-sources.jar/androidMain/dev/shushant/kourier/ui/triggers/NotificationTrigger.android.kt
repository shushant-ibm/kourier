package dev.shushant.kourier.ui.triggers

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import dev.shushant.kourier.core.model.TelemetryStats
import dev.shushant.kourier.ui.activity.KourierActivity
import dev.shushant.kourier.ui.export.AndroidContextHolder

import androidx.core.app.NotificationManagerCompat

actual object NotificationTrigger {
    private const val CHANNEL_ID = "kourier_telemetry_channel"
    private const val NOTIFICATION_ID = 404101

    @Volatile private var channelCreated = false

    private fun ensureChannel(notificationManager: NotificationManager) {
        if (channelCreated) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Kourier Network Inspector",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Live network telemetry and quick access to Kourier"
                setShowBadge(false)
            }
            notificationManager.createNotificationChannel(channel)
        }
        channelCreated = true
    }

    actual fun updateNotification(telemetry: TelemetryStats) {
        val context = AndroidContextHolder.applicationContext ?: return
        if (!NotificationManagerCompat.from(context).areNotificationsEnabled()) {
            return
        }
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return

        ensureChannel(notificationManager)

        val intent = Intent(context, KourierActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val title = "Kourier // ${telemetry.totalRequests} Requests (${telemetry.errorCount} Errors)"
        val contentText = "${telemetry.formattedThroughput} • ${if (telemetry.interceptorActive) "Active" else "Inactive"}"

        val clearIntent = Intent(context, KourierNotificationReceiver::class.java).apply {
            action = KourierNotificationReceiver.ACTION_CLEAR
        }
        val clearPendingIntent = PendingIntent.getBroadcast(
            context,
            11,
            clearIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentTitle(title)
            .setContentText(contentText)
            .setContentIntent(pendingIntent)
            .addAction(android.R.drawable.ic_menu_delete, "Clear", clearPendingIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .build()

        notificationManager.notify(NOTIFICATION_ID, notification)
    }

    actual fun dismiss() {
        val context = AndroidContextHolder.applicationContext ?: return
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return
        notificationManager.cancel(NOTIFICATION_ID)
    }
}
