package dev.shushant.kourier.ui.triggers

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.shushant.kourier.core.model.TelemetryStats
import dev.shushant.kourier.ui.theme.LocalKourierColors

/**
 * A sleek, non-intrusive status pill anchored at the top of the screen (flush with safe area).
 * Serves as an elegant iOS & Android alternative to the floating bubble when developers prefer
 * zero screen obstruction.
 */
@Composable
fun DynamicStatusPill(
    telemetry: TelemetryStats,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    onPositionChanged: ((x: Float, y: Float, width: Float, height: Float) -> Unit)? = null
) {
    val colors = LocalKourierColors.current
    val density = LocalDensity.current

    // Subtle pulsing animation on the live status dot
    val pulseScale = remember { Animatable(1f) }
    LaunchedEffect(telemetry.errorCount > 0) {
        pulseScale.animateTo(
            targetValue = 1.35f,
            animationSpec = infiniteRepeatable(
                animation = tween(durationMillis = 900, easing = LinearEasing),
                repeatMode = RepeatMode.Reverse
            )
        )
    }

    val statusDotColor = when {
        telemetry.errorCount > 0 -> colors.statusServerError
        telemetry.totalRequests > 0 -> colors.statusSuccess
        else -> colors.textMuted
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .padding(top = 10.dp),
        contentAlignment = Alignment.TopCenter
    ) {
        Row(
            modifier = Modifier
                .onGloballyPositioned { coordinates ->
                    val pos = coordinates.positionInWindow()
                    val size = coordinates.size
                    with(density) {
                        onPositionChanged?.invoke(
                            pos.x.toDp().value,
                            pos.y.toDp().value,
                            size.width.toDp().value,
                            size.height.toDp().value
                        )
                    }
                }
                .shadow(elevation = 6.dp, shape = RoundedCornerShape(18.dp), clip = false)
                .clip(RoundedCornerShape(18.dp))
                .background(colors.surfaceElevated.copy(alpha = 0.94f))
                .border(1.dp, colors.border.copy(alpha = 0.8f), RoundedCornerShape(18.dp))
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = onClick
                )
                .padding(horizontal = 14.dp, vertical = 6.dp)
                .height(24.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            // Live Status Indicator Dot
            Box(
                modifier = Modifier
                    .size(7.dp)
                    .scale(pulseScale.value)
                    .clip(CircleShape)
                    .background(statusDotColor)
            )

            Spacer(modifier = Modifier.width(8.dp))

            // KOURIER Brand Mark
            Text(
                text = "KOURIER",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = colors.textPrimary,
                letterSpacing = 1.sp
            )

            Spacer(modifier = Modifier.width(6.dp))

            Text(
                text = "·",
                fontSize = 12.sp,
                color = colors.textMuted
            )

            Spacer(modifier = Modifier.width(6.dp))

            // Total request count
            Text(
                text = "${telemetry.totalRequests} reqs",
                fontSize = 11.sp,
                color = colors.textSecondary,
                fontWeight = FontWeight.Medium
            )

            // Error badge if errors exist
            if (telemetry.errorCount > 0) {
                Spacer(modifier = Modifier.width(8.dp))
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(colors.statusServerError.copy(alpha = 0.2f))
                        .padding(horizontal = 5.dp, vertical = 1.dp)
                ) {
                    Text(
                        text = "${telemetry.errorCount} err",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.statusServerError
                    )
                }
            }
        }
    }
}
