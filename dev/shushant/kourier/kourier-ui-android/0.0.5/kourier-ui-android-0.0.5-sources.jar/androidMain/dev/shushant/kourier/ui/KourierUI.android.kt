package dev.shushant.kourier.ui

import android.content.Intent
import dev.shushant.kourier.core.KourierCore
import dev.shushant.kourier.ui.activity.KourierActivity
import dev.shushant.kourier.ui.export.AndroidContextHolder
import dev.shushant.kourier.ui.triggers.NotificationTrigger
import dev.shushant.kourier.ui.triggers.ShakeDetector
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

actual object KourierUI {
    private var shakeDetector: ShakeDetector? = null
    private var notificationScope: CoroutineScope? = null

    actual fun show() {
        val context = AndroidContextHolder.currentActivity ?: AndroidContextHolder.applicationContext ?: return
        val intent = Intent(context, KourierActivity::class.java).apply {
            if (context !is android.app.Activity) {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
        }
        context.startActivity(intent)
    }

    actual fun hide() {
        (AndroidContextHolder.currentActivity as? KourierActivity)?.finish()
    }

    actual fun startTriggers() {
        val config = KourierCore.config
        if (config.enableShakeGesture) {
            shakeDetector = ShakeDetector().apply {
                start { show() }
            }
        }
        if (config.enableNotification) {
            val scope = CoroutineScope(Dispatchers.Default + Job())
            notificationScope = scope
            scope.launch {
                KourierCore.eventBus.telemetry.collect { telemetry ->
                    NotificationTrigger.updateNotification(telemetry)
                }
            }
        }
    }

    actual fun stopTriggers() {
        shakeDetector?.stop()
        shakeDetector = null
        notificationScope?.cancel()
        notificationScope = null
        NotificationTrigger.dismiss()
    }
}
