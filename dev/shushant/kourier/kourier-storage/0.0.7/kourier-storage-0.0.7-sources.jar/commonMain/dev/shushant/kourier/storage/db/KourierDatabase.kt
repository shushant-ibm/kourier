package dev.shushant.kourier.storage.db

import app.cash.sqldelight.Transacter
import app.cash.sqldelight.db.QueryResult
import app.cash.sqldelight.db.SqlDriver
import app.cash.sqldelight.db.SqlSchema
import dev.shushant.kourier.storage.db.kourierstorage.newInstance
import dev.shushant.kourier.storage.db.kourierstorage.schema
import kotlin.Unit

public interface KourierDatabase : Transacter {
  public val kourierDatabaseQueries: KourierDatabaseQueries

  public companion object {
    public val Schema: SqlSchema<QueryResult.Value<Unit>>
      get() = KourierDatabase::class.schema

    public operator fun invoke(driver: SqlDriver): KourierDatabase = KourierDatabase::class.newInstance(driver)
  }
}
