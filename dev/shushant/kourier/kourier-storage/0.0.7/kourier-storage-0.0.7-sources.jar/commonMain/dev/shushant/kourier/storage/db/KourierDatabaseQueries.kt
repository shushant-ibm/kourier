package dev.shushant.kourier.storage.db

import app.cash.sqldelight.Query
import app.cash.sqldelight.TransacterImpl
import app.cash.sqldelight.db.QueryResult
import app.cash.sqldelight.db.SqlCursor
import app.cash.sqldelight.db.SqlDriver
import kotlin.Any
import kotlin.Long
import kotlin.String

public class KourierDatabaseQueries(
  driver: SqlDriver,
) : TransacterImpl(driver) {
  public fun selectAll(): Query<String> = Query(892_629_812, arrayOf("TransactionEntity"), driver, "KourierDatabase.sq", "selectAll", """
  |SELECT serializedData FROM TransactionEntity
  |ORDER BY timestamp DESC
  """.trimMargin()) { cursor ->
    cursor.getString(0)!!
  }

  public fun selectById(id: String): Query<String> = SelectByIdQuery(id) { cursor ->
    cursor.getString(0)!!
  }

  public fun searchByQuery(query: String): Query<String> = SearchByQueryQuery(query) { cursor ->
    cursor.getString(0)!!
  }

  public fun countAll(): Query<Long> = Query(-10_811_389, arrayOf("TransactionEntity"), driver, "KourierDatabase.sq", "countAll", "SELECT COUNT(*) FROM TransactionEntity") { cursor ->
    cursor.getLong(0)!!
  }

  /**
   * @return The number of rows updated.
   */
  public fun insertOrReplace(
    id: String,
    timestamp: Long,
    method: String,
    url: String,
    host: String,
    path: String,
    statusCode: Long?,
    durationMs: Long,
    isFailed: Long,
    serializedData: String,
  ): QueryResult<Long> {
    val result = driver.execute(891_633_031, """
        |INSERT OR REPLACE INTO TransactionEntity(
        |    id, timestamp, method, url, host, path, statusCode, durationMs, isFailed, serializedData
        |) VALUES (
        |    ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
        |)
        """.trimMargin(), 10) {
          var parameterIndex = 0
          bindString(parameterIndex++, id)
          bindLong(parameterIndex++, timestamp)
          bindString(parameterIndex++, method)
          bindString(parameterIndex++, url)
          bindString(parameterIndex++, host)
          bindString(parameterIndex++, path)
          bindLong(parameterIndex++, statusCode)
          bindLong(parameterIndex++, durationMs)
          bindLong(parameterIndex++, isFailed)
          bindString(parameterIndex++, serializedData)
        }
    notifyQueries(891_633_031) { emit ->
      emit("TransactionEntity")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun deleteById(id: String): QueryResult<Long> {
    val result = driver.execute(1_027_339_726, """DELETE FROM TransactionEntity WHERE id = ?""", 1) {
          var parameterIndex = 0
          bindString(parameterIndex++, id)
        }
    notifyQueries(1_027_339_726) { emit ->
      emit("TransactionEntity")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun deleteAll(): QueryResult<Long> {
    val result = driver.execute(-2_045_071_323, """DELETE FROM TransactionEntity""", 0)
    notifyQueries(-2_045_071_323) { emit ->
      emit("TransactionEntity")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun deleteOlderThan(timestampCutoff: Long): QueryResult<Long> {
    val result = driver.execute(535_898_201, """DELETE FROM TransactionEntity WHERE timestamp < ?""", 1) {
          var parameterIndex = 0
          bindLong(parameterIndex++, timestampCutoff)
        }
    notifyQueries(535_898_201) { emit ->
      emit("TransactionEntity")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun trimToCount(maxCount: Long): QueryResult<Long> {
    val result = driver.execute(383_256_897, """
        |DELETE FROM TransactionEntity
        |WHERE id NOT IN (
        |    SELECT id FROM TransactionEntity
        |    ORDER BY timestamp DESC, id DESC
        |    LIMIT ?
        |)
        """.trimMargin(), 1) {
          var parameterIndex = 0
          bindLong(parameterIndex++, maxCount)
        }
    notifyQueries(383_256_897) { emit ->
      emit("TransactionEntity")
    }
    return result
  }

  private inner class SelectByIdQuery<out T : Any>(
    public val id: String,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("TransactionEntity", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("TransactionEntity", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(1_901_761_695, """
    |SELECT serializedData FROM TransactionEntity
    |WHERE id = ?
    """.trimMargin(), mapper, 1) {
      var parameterIndex = 0
      bindString(parameterIndex++, id)
    }

    override fun toString(): String = "KourierDatabase.sq:selectById"
  }

  private inner class SearchByQueryQuery<out T : Any>(
    public val query: String,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("TransactionEntity", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("TransactionEntity", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(1_070_082_200, """
    |SELECT serializedData FROM TransactionEntity
    |WHERE url LIKE '%' || ? || '%' OR host LIKE '%' || ? || '%' OR path LIKE '%' || ? || '%'
    |ORDER BY timestamp DESC
    """.trimMargin(), mapper, 3) {
      var parameterIndex = 0
      bindString(parameterIndex++, query)
      bindString(parameterIndex++, query)
      bindString(parameterIndex++, query)
    }

    override fun toString(): String = "KourierDatabase.sq:searchByQuery"
  }
}
