package dev.shushant.kourier.storage.db

import kotlin.Long
import kotlin.String

public data class TransactionEntity(
  public val id: String,
  public val timestamp: Long,
  public val method: String,
  public val url: String,
  public val host: String,
  public val path: String,
  public val statusCode: Long?,
  public val durationMs: Long,
  public val isFailed: Long,
  public val serializedData: String,
)
