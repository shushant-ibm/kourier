package dev.shushant.kourier.storage.db.kourierstorage

import app.cash.sqldelight.TransacterImpl
import app.cash.sqldelight.db.AfterVersion
import app.cash.sqldelight.db.QueryResult
import app.cash.sqldelight.db.SqlDriver
import app.cash.sqldelight.db.SqlSchema
import dev.shushant.kourier.storage.db.KourierDatabase
import dev.shushant.kourier.storage.db.KourierDatabaseQueries
import kotlin.Long
import kotlin.Unit
import kotlin.reflect.KClass

internal val KClass<KourierDatabase>.schema: SqlSchema<QueryResult.Value<Unit>>
  get() = KourierDatabaseImpl.Schema

internal fun KClass<KourierDatabase>.newInstance(driver: SqlDriver): KourierDatabase = KourierDatabaseImpl(driver)

private class KourierDatabaseImpl(
  driver: SqlDriver,
) : TransacterImpl(driver),
    KourierDatabase {
  override val kourierDatabaseQueries: KourierDatabaseQueries = KourierDatabaseQueries(driver)

  public object Schema : SqlSchema<QueryResult.Value<Unit>> {
    override val version: Long
      get() = 1

    override fun create(driver: SqlDriver): QueryResult.Value<Unit> {
      driver.execute(null, """
          |CREATE TABLE TransactionEntity (
          |    id TEXT PRIMARY KEY NOT NULL,
          |    timestamp INTEGER NOT NULL,
          |    method TEXT NOT NULL,
          |    url TEXT NOT NULL,
          |    host TEXT NOT NULL,
          |    path TEXT NOT NULL,
          |    statusCode INTEGER,
          |    durationMs INTEGER NOT NULL,
          |    isFailed INTEGER NOT NULL,
          |    serializedData TEXT NOT NULL
          |)
          """.trimMargin(), 0)
      driver.execute(null, "CREATE INDEX idx_transaction_timestamp ON TransactionEntity(timestamp DESC)", 0)
      driver.execute(null, "CREATE INDEX idx_transaction_host ON TransactionEntity(host)", 0)
      driver.execute(null, "CREATE INDEX idx_transaction_status ON TransactionEntity(statusCode)", 0)
      driver.execute(null, "CREATE INDEX idx_transaction_failed ON TransactionEntity(isFailed)", 0)
      return QueryResult.Unit
    }

    override fun migrate(
      driver: SqlDriver,
      oldVersion: Long,
      newVersion: Long,
      vararg callbacks: AfterVersion,
    ): QueryResult.Value<Unit> = QueryResult.Unit
  }
}
