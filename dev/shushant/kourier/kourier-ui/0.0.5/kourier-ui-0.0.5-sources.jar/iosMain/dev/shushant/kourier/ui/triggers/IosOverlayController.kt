package dev.shushant.kourier.ui.triggers

import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.window.ComposeUIViewController
import dev.shushant.kourier.core.KourierCore
import dev.shushant.kourier.ui.KourierUI
import dev.shushant.kourier.ui.theme.KourierTheme
import kotlinx.cinterop.ExperimentalForeignApi
import platform.UIKit.UIApplication
import platform.UIKit.UIColor
import platform.UIKit.UISceneActivationStateForegroundActive
import platform.UIKit.UIWindow
import platform.UIKit.UIWindowLevelNormal
import platform.UIKit.UIWindowScene

@OptIn(ExperimentalForeignApi::class)
object IosOverlayController {
    private var overlayWindow: UIWindow? = null

    fun install() {
        try {
            if (overlayWindow != null) return

            val app = UIApplication.sharedApplication
            val scenes = app.connectedScenes
            val scene = scenes.filterIsInstance<UIWindowScene>().firstOrNull {
                it.activationState == UISceneActivationStateForegroundActive
            } ?: scenes.filterIsInstance<UIWindowScene>().firstOrNull() ?: return

            val window = UIWindow(windowScene = scene)
            window.backgroundColor = UIColor.clearColor
            window.windowLevel = UIWindowLevelNormal + 1.0

            val bubbleVC = ComposeUIViewController {
                KourierTheme {
                    val telemetry by KourierCore.eventBus.telemetry.collectAsState()
                    FloatingDebugBubble(
                        telemetry = telemetry,
                        onClick = { KourierUI.show() }
                    )
                }
            }
            bubbleVC.view.backgroundColor = UIColor.clearColor

            window.rootViewController = bubbleVC
            window.hidden = false
            overlayWindow = window
        } catch (_: Throwable) {}
    }

    fun uninstall() {
        try {
            overlayWindow?.hidden = true
            overlayWindow?.rootViewController = null
            overlayWindow = null
        } catch (_: Throwable) {}
    }
}

