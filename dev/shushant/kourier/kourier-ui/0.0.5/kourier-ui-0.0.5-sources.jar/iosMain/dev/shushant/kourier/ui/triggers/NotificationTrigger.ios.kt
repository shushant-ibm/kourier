package dev.shushant.kourier.ui.triggers

import dev.shushant.kourier.core.model.TelemetryStats

actual object NotificationTrigger {
    actual fun updateNotification(telemetry: TelemetryStats) {
        // Notification tray is an Android-specific feature; iOS relies on shake gesture and draggable bubble overlay
    }

    actual fun dismiss() {
    }
}
