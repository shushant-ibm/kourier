package dev.shushant.kourier.ui.triggers

import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.window.ComposeUIViewController
import dev.shushant.kourier.core.KourierCore
import dev.shushant.kourier.ui.KourierUI
import dev.shushant.kourier.ui.theme.KourierTheme
import kotlinx.cinterop.CValue
import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.cinterop.useContents
import platform.CoreGraphics.CGPoint
import platform.Foundation.NSNotificationCenter
import platform.Foundation.NSOperationQueue
import platform.Foundation.NSThread
import platform.UIKit.UIApplication
import platform.UIKit.UIColor
import platform.UIKit.UIEvent
import platform.UIKit.UIView
import platform.UIKit.UIWindow
import platform.UIKit.UIWindowLevelStatusBar
import platform.UIKit.UIWindowScene
import platform.UIKit.UISceneActivationStateForegroundActive
import platform.UIKit.UISceneDidActivateNotification

// UIWindowLevelStatusBar (1000) keeps the bubble above all app content but
// below system alerts (UIWindowLevelAlert = 2000).
// Not a const because UIWindowLevelStatusBar is not a compile-time constant.
private val BUBBLE_WINDOW_LEVEL = UIWindowLevelStatusBar - 1.0

@OptIn(ExperimentalForeignApi::class, kotlinx.cinterop.BetaInteropApi::class)
private class PassthroughUIWindow : UIWindow {
    @OverrideInit
    constructor(windowScene: UIWindowScene) : super(windowScene = windowScene)

    var bubbleX: Double = -1000.0
    var bubbleY: Double = 140.0
    var bubbleSize: Double = 58.0

    override fun hitTest(point: CValue<CGPoint>, withEvent: UIEvent?): UIView? {
        val hitView = super.hitTest(point, withEvent) ?: return null
        var isInside = false
        point.useContents {
            val margin = 16.0
            isInside = x >= (bubbleX - margin) && x <= (bubbleX + bubbleSize + margin) &&
                       y >= (bubbleY - margin) && y <= (bubbleY + bubbleSize + margin)
        }
        return if (isInside) hitView else null
    }
}

@OptIn(ExperimentalForeignApi::class, androidx.compose.ui.ExperimentalComposeUiApi::class)
object IosOverlayController {
    internal var overlayWindow: UIWindow? = null
    // Retained so we can remove it in uninstall().
    private var sceneObserver: Any? = null

    fun install() {
        // UIKit must be mutated on the main thread.
        if (!NSThread.isMainThread()) {
            NSOperationQueue.mainQueue.addOperationWithBlock { install() }
            return
        }
        try {
            if (overlayWindow != null) return

            // Try to install immediately — works when called after the first scene activates
            // (e.g. from applicationDidBecomeActive or scene(_:didActivate:)).
            val scene = activeScene()
            if (scene != null) {
                installOnScene(scene)
            } else {
                // Called too early (e.g. App.init before any UIWindowScene exists).
                // Register for the first scene-activation notification and install then.
                // The observer is self-removing after the first delivery.
                sceneObserver = NSNotificationCenter.defaultCenter.addObserverForName(
                    name = UISceneDidActivateNotification,
                    `object` = null,
                    queue = NSOperationQueue.mainQueue
                ) { _ ->
                    // Remove the observer first so it doesn't fire again.
                    sceneObserver?.let {
                        NSNotificationCenter.defaultCenter.removeObserver(it)
                        sceneObserver = null
                    }
                    // Retry now that a scene is active.
                    if (overlayWindow == null) {
                        activeScene()?.let { s -> installOnScene(s) }
                    }
                }
            }
        } catch (_: Throwable) {}
    }

    private fun activeScene(): UIWindowScene? {
        val app = UIApplication.sharedApplication
        @Suppress("SENSELESS_COMPARISON")
        val scenes = app.connectedScenes
        @Suppress("SENSELESS_COMPARISON")
        if (scenes == null) return null
        return scenes.filterIsInstance<UIWindowScene>().firstOrNull {
            it.activationState == UISceneActivationStateForegroundActive
        } ?: scenes.filterIsInstance<UIWindowScene>().firstOrNull()
    }

    private fun installOnScene(scene: UIWindowScene) {
        try {
            val window = PassthroughUIWindow(windowScene = scene)
            window.backgroundColor = UIColor.clearColor
            window.windowLevel = BUBBLE_WINDOW_LEVEL
            window.setUserInteractionEnabled(true)

            // Seed initial position in UIKit points based on scene width
            scene.coordinateSpace.bounds.useContents {
                window.bubbleSize = 58.0
                window.bubbleX = size.width - window.bubbleSize - 16.0
                window.bubbleY = 140.0
            }

            val bubbleVC = ComposeUIViewController(configure = {
                opaque = false
            }) {
                KourierTheme {
                    val telemetry by KourierCore.eventBus.telemetry.collectAsState()
                    FloatingDebugBubble(
                        telemetry = telemetry,
                        onClick = { KourierUI.show() },
                        onPositionChanged = { x, y, size ->
                            window.bubbleX = x.toDouble()
                            window.bubbleY = y.toDouble()
                            window.bubbleSize = size.toDouble()
                        }
                    )
                }
            }
            bubbleVC.view.backgroundColor = UIColor.clearColor

            window.rootViewController = bubbleVC
            // Setting isHidden = false is sufficient to render an overlay UIWindow.
            // PassthroughUIWindow ensures touches outside the bubble frame pass through to the host window.
            window.hidden = false
            overlayWindow = window
        } catch (_: Throwable) {}
    }

    fun uninstall() {
        // UIKit must be mutated on the main thread.
        if (!NSThread.isMainThread()) {
            NSOperationQueue.mainQueue.addOperationWithBlock { uninstall() }
            return
        }
        try {
            // Cancel any pending deferred install.
            sceneObserver?.let {
                NSNotificationCenter.defaultCenter.removeObserver(it)
                sceneObserver = null
            }
            overlayWindow?.hidden = true
            overlayWindow?.rootViewController = null
            overlayWindow = null
        } catch (_: Throwable) {}
    }
}

