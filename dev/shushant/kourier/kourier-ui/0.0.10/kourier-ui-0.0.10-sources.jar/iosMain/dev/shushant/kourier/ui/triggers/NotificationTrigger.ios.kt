package dev.shushant.kourier.ui.triggers

import dev.shushant.kourier.core.model.TelemetryStats
import platform.UserNotifications.UNAuthorizationOptionAlert
import platform.UserNotifications.UNAuthorizationOptionBadge
import platform.UserNotifications.UNAuthorizationOptionSound
import platform.UserNotifications.UNMutableNotificationContent
import platform.UserNotifications.UNNotificationRequest
import platform.UserNotifications.UNNotificationSound
import platform.UserNotifications.UNUserNotificationCenter

actual object NotificationTrigger {
    private const val NOTIFICATION_ID = "kourier_live_telemetry"
    private var lastErrorCount: Long = 0L
    private var isAuthorized: Boolean = false

    private fun requestPermissionIfNeeded() {
        if (isAuthorized) return
        try {
            val center = UNUserNotificationCenter.currentNotificationCenter()
            center.requestAuthorizationWithOptions(
                UNAuthorizationOptionAlert or UNAuthorizationOptionSound or UNAuthorizationOptionBadge
            ) { granted, _ ->
                isAuthorized = granted
            }
        } catch (_: Throwable) {}
    }

    actual fun updateNotification(telemetry: TelemetryStats) {
        try {
            requestPermissionIfNeeded()
            if (telemetry.errorCount > lastErrorCount) {
                lastErrorCount = telemetry.errorCount
                val center = UNUserNotificationCenter.currentNotificationCenter()
                val content = UNMutableNotificationContent().apply {
                    setTitle("Kourier Network Alert")
                    setBody("${telemetry.errorCount} error(s) detected • ${telemetry.totalRequests} total requests")
                    setSound(UNNotificationSound.defaultSound())
                }
                val request = UNNotificationRequest.requestWithIdentifier(
                    identifier = NOTIFICATION_ID,
                    content = content,
                    trigger = null
                )
                center.addNotificationRequest(request, null)
            }
        } catch (_: Throwable) {}
    }

    actual fun dismiss() {
        try {
            val center = UNUserNotificationCenter.currentNotificationCenter()
            center.removeDeliveredNotificationsWithIdentifiers(listOf(NOTIFICATION_ID))
            center.removePendingNotificationRequestsWithIdentifiers(listOf(NOTIFICATION_ID))
        } catch (_: Throwable) {}
    }
}
