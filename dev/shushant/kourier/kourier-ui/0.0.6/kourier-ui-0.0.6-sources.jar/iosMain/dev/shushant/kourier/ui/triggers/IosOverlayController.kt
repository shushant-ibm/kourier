package dev.shushant.kourier.ui.triggers

import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.window.ComposeUIViewController
import dev.shushant.kourier.core.KourierCore
import dev.shushant.kourier.ui.KourierUI
import dev.shushant.kourier.ui.theme.KourierTheme
import kotlinx.cinterop.ExperimentalForeignApi
import platform.Foundation.NSOperationQueue
import platform.UIKit.UIApplication
import platform.UIKit.UIColor
import platform.UIKit.UISceneActivationStateForegroundActive
import platform.UIKit.UIWindow
import platform.UIKit.UIWindowLevelStatusBar
import platform.UIKit.UIWindowScene

// UIWindowLevelStatusBar (1000) keeps the bubble above all app content but
// below system alerts (UIWindowLevelAlert = 2000).
// Not a const because UIWindowLevelStatusBar is not a compile-time constant.
private val BUBBLE_WINDOW_LEVEL = UIWindowLevelStatusBar - 1.0

@OptIn(ExperimentalForeignApi::class)
object IosOverlayController {
    private var overlayWindow: UIWindow? = null

    fun install() {
        // UIKit must be mutated on the main thread.
        if (!platform.Foundation.NSThread.isMainThread()) {
            NSOperationQueue.mainQueue.addOperationWithBlock { install() }
            return
        }
        try {
            if (overlayWindow != null) return

            val app = UIApplication.sharedApplication
            val scenes = app.connectedScenes
            val scene = scenes.filterIsInstance<UIWindowScene>().firstOrNull {
                it.activationState == UISceneActivationStateForegroundActive
            } ?: scenes.filterIsInstance<UIWindowScene>().firstOrNull() ?: return

            val window = UIWindow(windowScene = scene)
            window.backgroundColor = UIColor.clearColor
            window.windowLevel = BUBBLE_WINDOW_LEVEL
            window.setUserInteractionEnabled(true)

            val bubbleVC = ComposeUIViewController {
                KourierTheme {
                    val telemetry by KourierCore.eventBus.telemetry.collectAsState()
                    FloatingDebugBubble(
                        telemetry = telemetry,
                        onClick = { KourierUI.show() }
                    )
                }
            }
            bubbleVC.view.backgroundColor = UIColor.clearColor

            window.rootViewController = bubbleVC
            // makeKeyAndVisible() is required for a secondary UIWindow — hidden=false alone
            // does not render the window in the responder chain.
            window.makeKeyAndVisible()
            overlayWindow = window
        } catch (_: Throwable) {}
    }

    fun uninstall() {
        // UIKit must be mutated on the main thread.
        if (!platform.Foundation.NSThread.isMainThread()) {
            NSOperationQueue.mainQueue.addOperationWithBlock { uninstall() }
            return
        }
        try {
            overlayWindow?.hidden = true
            overlayWindow?.rootViewController = null
            overlayWindow = null
        } catch (_: Throwable) {}
    }
}

