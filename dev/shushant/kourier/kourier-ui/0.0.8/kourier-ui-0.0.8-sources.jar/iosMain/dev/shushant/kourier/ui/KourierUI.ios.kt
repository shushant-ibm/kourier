package dev.shushant.kourier.ui

import dev.shushant.kourier.core.KourierCore
import dev.shushant.kourier.ui.controller.KourierViewController
import dev.shushant.kourier.ui.triggers.IosOverlayController
import dev.shushant.kourier.ui.triggers.ShakeDetector
import platform.UIKit.UIApplication
import platform.UIKit.UIModalPresentationFullScreen
import platform.UIKit.UISceneActivationStateForegroundActive
import platform.UIKit.UIWindow
import platform.UIKit.UIWindowScene

actual object KourierUI {
    private var shakeDetector: ShakeDetector? = null

    private fun getActiveWindow(): UIWindow? {
        return try {
            val app = UIApplication.sharedApplication
            val scenes = app.connectedScenes
            val activeScene = scenes.filterIsInstance<UIWindowScene>().firstOrNull {
                it.activationState == UISceneActivationStateForegroundActive
            } ?: scenes.filterIsInstance<UIWindowScene>().firstOrNull()

            val overlayWindow = IosOverlayController.overlayWindow
            val windows = (activeScene?.windows?.filterIsInstance<UIWindow>() ?: emptyList())
                .filter { it !== overlayWindow }  // never use the Kourier bubble window
            windows.firstOrNull { it.isKeyWindow() }
                ?: windows.firstOrNull()
                ?: app.keyWindow
        } catch (_: Throwable) {
            null
        }
    }

    actual fun show() {
        if (!platform.Foundation.NSThread.isMainThread()) {
            platform.Foundation.NSOperationQueue.mainQueue.addOperationWithBlock {
                show()
            }
            return
        }
        try {
            val window = getActiveWindow() ?: return
            var topController = window.rootViewController ?: return
            while (topController.presentedViewController != null) {
                topController = topController.presentedViewController!!
            }

            if (topController.isBeingPresented() || topController.isBeingDismissed()) {
                return
            }

            val kourierVC = KourierViewController.create()
            kourierVC.modalPresentationStyle = UIModalPresentationFullScreen
            topController.presentViewController(kourierVC, animated = true, completion = null)
        } catch (_: Throwable) {}
    }

    actual fun hide() {
        if (!platform.Foundation.NSThread.isMainThread()) {
            platform.Foundation.NSOperationQueue.mainQueue.addOperationWithBlock {
                hide()
            }
            return
        }
        try {
            val window = getActiveWindow() ?: return
            val topController = window.rootViewController?.presentedViewController
            topController?.dismissViewControllerAnimated(true, completion = null)
        } catch (_: Throwable) {}
    }

    actual fun startTriggers() {
        try {
            val config = KourierCore.config
            if (config.enableShakeGesture) {
                shakeDetector = ShakeDetector().apply {
                    start { show() }
                }
            }
            if (config.enableNotification) {
                IosOverlayController.install()
            }
        } catch (_: Throwable) {}
    }

    actual fun stopTriggers() {
        try {
            shakeDetector?.stop()
            shakeDetector = null
            IosOverlayController.uninstall()
        } catch (_: Throwable) {}
    }
}
