package dev.shushant.kourier.ui.triggers

import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.window.ComposeUIViewController
import dev.shushant.kourier.core.KourierCore
import dev.shushant.kourier.ui.KourierUI
import dev.shushant.kourier.ui.theme.KourierTheme
import kotlinx.cinterop.ExperimentalForeignApi
import platform.Foundation.NSNotificationCenter
import platform.Foundation.NSOperationQueue
import platform.Foundation.NSThread
import platform.UIKit.UIApplication
import platform.UIKit.UIColor
import platform.UIKit.UISceneActivationStateForegroundActive
import platform.UIKit.UISceneDidActivateNotification
import platform.UIKit.UIWindow
import platform.UIKit.UIWindowLevelStatusBar
import platform.UIKit.UIWindowScene

// UIWindowLevelStatusBar (1000) keeps the bubble above all app content but
// below system alerts (UIWindowLevelAlert = 2000).
// Not a const because UIWindowLevelStatusBar is not a compile-time constant.
private val BUBBLE_WINDOW_LEVEL = UIWindowLevelStatusBar - 1.0

@OptIn(ExperimentalForeignApi::class)
object IosOverlayController {
    internal var overlayWindow: UIWindow? = null
    // Retained so we can remove it in uninstall().
    private var sceneObserver: Any? = null

    fun install() {
        // UIKit must be mutated on the main thread.
        if (!NSThread.isMainThread()) {
            NSOperationQueue.mainQueue.addOperationWithBlock { install() }
            return
        }
        try {
            if (overlayWindow != null) return

            // Try to install immediately — works when called after the first scene activates
            // (e.g. from applicationDidBecomeActive or scene(_:didActivate:)).
            val scene = activeScene()
            if (scene != null) {
                installOnScene(scene)
            } else {
                // Called too early (e.g. App.init before any UIWindowScene exists).
                // Register for the first scene-activation notification and install then.
                // The observer is self-removing after the first delivery.
                sceneObserver = NSNotificationCenter.defaultCenter.addObserverForName(
                    name = UISceneDidActivateNotification,
                    `object` = null,
                    queue = NSOperationQueue.mainQueue
                ) { _ ->
                    // Remove the observer first so it doesn't fire again.
                    sceneObserver?.let {
                        NSNotificationCenter.defaultCenter.removeObserver(it)
                        sceneObserver = null
                    }
                    // Retry now that a scene is active.
                    if (overlayWindow == null) {
                        activeScene()?.let { s -> installOnScene(s) }
                    }
                }
            }
        } catch (_: Throwable) {}
    }

    private fun activeScene(): UIWindowScene? {
        val app = UIApplication.sharedApplication
        val scenes = app.connectedScenes
        return scenes.filterIsInstance<UIWindowScene>().firstOrNull {
            it.activationState == UISceneActivationStateForegroundActive
        } ?: scenes.filterIsInstance<UIWindowScene>().firstOrNull()
    }

    private fun installOnScene(scene: UIWindowScene) {
        try {
            val window = UIWindow(windowScene = scene)
            window.backgroundColor = UIColor.clearColor
            window.windowLevel = BUBBLE_WINDOW_LEVEL
            window.setUserInteractionEnabled(true)

            val bubbleVC = ComposeUIViewController {
                KourierTheme {
                    val telemetry by KourierCore.eventBus.telemetry.collectAsState()
                    FloatingDebugBubble(
                        telemetry = telemetry,
                        onClick = { KourierUI.show() }
                    )
                }
            }
            bubbleVC.view.backgroundColor = UIColor.clearColor

            window.rootViewController = bubbleVC
            // Do NOT call makeKeyAndVisible() — that would steal key-window status from the
            // host app's window, causing the host UI to go blank.
            // Setting isHidden = false is sufficient to render an overlay UIWindow.
            // Touches on transparent areas fall through to the host window automatically.
            window.hidden = false
            overlayWindow = window
        } catch (_: Throwable) {}
    }

    fun uninstall() {
        // UIKit must be mutated on the main thread.
        if (!NSThread.isMainThread()) {
            NSOperationQueue.mainQueue.addOperationWithBlock { uninstall() }
            return
        }
        try {
            // Cancel any pending deferred install.
            sceneObserver?.let {
                NSNotificationCenter.defaultCenter.removeObserver(it)
                sceneObserver = null
            }
            overlayWindow?.hidden = true
            overlayWindow?.rootViewController = null
            overlayWindow = null
        } catch (_: Throwable) {}
    }
}

