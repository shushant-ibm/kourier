package dev.shushant.kourier.ui

import dev.shushant.kourier.core.KourierCore
import dev.shushant.kourier.ui.controller.KourierViewController
import dev.shushant.kourier.ui.triggers.IosOverlayController
import dev.shushant.kourier.ui.triggers.ShakeDetector
import platform.UIKit.UIApplication
import platform.UIKit.UIModalPresentationFullScreen
import platform.UIKit.UISceneActivationStateForegroundActive
import platform.UIKit.UIWindow
import platform.UIKit.UIWindowScene

actual object KourierUI {
    private var shakeDetector: ShakeDetector? = null

    private fun getActiveWindow(): UIWindow? {
        val scenes = UIApplication.sharedApplication.connectedScenes
        val activeScene = scenes.filterIsInstance<UIWindowScene>().firstOrNull {
            it.activationState == UISceneActivationStateForegroundActive
        } ?: scenes.filterIsInstance<UIWindowScene>().firstOrNull()

        val windows = activeScene?.windows?.filterIsInstance<UIWindow>() ?: emptyList()
        return windows.firstOrNull { it.isKeyWindow() }
            ?: windows.firstOrNull()
            ?: UIApplication.sharedApplication.keyWindow
    }

    actual fun show() {
        val window = getActiveWindow() ?: return
        var topController = window.rootViewController
        while (topController?.presentedViewController != null) {
            topController = topController.presentedViewController
        }

        val kourierVC = KourierViewController.create()
        kourierVC.modalPresentationStyle = UIModalPresentationFullScreen
        topController?.presentViewController(kourierVC, animated = true, completion = null)
    }

    actual fun hide() {
        val window = getActiveWindow() ?: return
        val topController = window.rootViewController?.presentedViewController
        topController?.dismissViewControllerAnimated(true, completion = null)
    }

    actual fun startTriggers() {
        val config = KourierCore.config
        if (config.enableShakeGesture) {
            shakeDetector = ShakeDetector().apply {
                start { show() }
            }
        }
        if (config.enableFloatingBubble) {
            IosOverlayController.install()
        }
    }

    actual fun stopTriggers() {
        shakeDetector?.stop()
        shakeDetector = null
        IosOverlayController.uninstall()
    }
}
