package dev.shushant.kourier.ui.triggers

import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.window.ComposeUIViewController
import dev.shushant.kourier.core.KourierCore
import dev.shushant.kourier.ui.KourierUI
import dev.shushant.kourier.ui.theme.KourierTheme
import kotlinx.cinterop.ExperimentalForeignApi
import platform.UIKit.UIApplication
import platform.UIKit.UIColor
import platform.UIKit.UISceneActivationStateForegroundActive
import platform.UIKit.UIWindow
import platform.UIKit.UIWindowLevelNormal
import platform.UIKit.UIWindowScene

@OptIn(ExperimentalForeignApi::class)
object IosOverlayController {
    private var overlayWindow: UIWindow? = null
    private var notificationObserver: Any? = null

    fun install() {
        if (overlayWindow != null) return

        val scenes = UIApplication.sharedApplication.connectedScenes
        val scene = scenes.filterIsInstance<UIWindowScene>().firstOrNull {
            it.activationState == UISceneActivationStateForegroundActive
        } ?: scenes.filterIsInstance<UIWindowScene>().firstOrNull()

        if (scene == null) {
            // App was initialized before any UIWindowScene became active (e.g. SwiftUI App.init()).
            // Register an observer to attach once the application becomes active.
            if (notificationObserver == null) {
                notificationObserver = platform.Foundation.NSNotificationCenter.defaultCenter.addObserverForName(
                    name = platform.UIKit.UIApplicationDidBecomeActiveNotification,
                    `object` = null,
                    queue = platform.Foundation.NSOperationQueue.mainQueue
                ) {
                    install()
                }
            }
            return
        }

        // Clean up observer if it was registered
        if (notificationObserver != null) {
            platform.Foundation.NSNotificationCenter.defaultCenter.removeObserver(notificationObserver!!)
            notificationObserver = null
        }

        val window = UIWindow(windowScene = scene)
        window.backgroundColor = UIColor.clearColor
        window.windowLevel = UIWindowLevelNormal + 1.0

        val bubbleVC = ComposeUIViewController {
            KourierTheme {
                val telemetry by KourierCore.eventBus.telemetry.collectAsState()
                FloatingDebugBubble(
                    telemetry = telemetry,
                    onClick = { KourierUI.show() }
                )
            }
        }
        bubbleVC.view.backgroundColor = UIColor.clearColor

        window.rootViewController = bubbleVC
        window.hidden = false
        overlayWindow = window
    }

    fun uninstall() {
        if (notificationObserver != null) {
            platform.Foundation.NSNotificationCenter.defaultCenter.removeObserver(notificationObserver!!)
            notificationObserver = null
        }
        overlayWindow?.hidden = true
        overlayWindow?.rootViewController = null
        overlayWindow = null
    }
}

