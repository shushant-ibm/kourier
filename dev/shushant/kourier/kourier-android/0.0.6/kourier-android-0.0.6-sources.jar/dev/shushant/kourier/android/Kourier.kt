package dev.shushant.kourier.android

import android.content.Context
import dev.shushant.kourier.core.KourierCore
import dev.shushant.kourier.core.config.KourierConfig
import dev.shushant.kourier.storage.SQLiteKourierStorage
import dev.shushant.kourier.storage.db.DatabaseDriverFactory
import dev.shushant.kourier.ui.KourierUI
import dev.shushant.kourier.ui.export.AndroidContextHolder

/**
 * Single entry point for the Kourier SDK on Android.
 *
 * Usage in Application.onCreate():
 *
 *   Kourier.init(this) {
 *       redactHeaders("Authorization")
 *       enableShakeGesture(true)
 *   }
 */
object Kourier {

    /**
     * Initialises Kourier. Call once from Application.onCreate().
     */
    fun init(
        context: Context,
        config: KourierConfig = KourierConfig.Builder().build()
    ) {
        AndroidContextHolder.applicationContext = context.applicationContext
        val driver = DatabaseDriverFactory(context.applicationContext).createDriver()
        val storage = SQLiteKourierStorage(driver)
        KourierCore.initialize(config = config, storage = storage)
        KourierUI.startTriggers()
        if (config.enableFloatingBubble) {
            val app = (context.applicationContext as? android.app.Application)
                ?: (context as? android.app.Application)
            app?.let { dev.shushant.kourier.android.ui.AndroidOverlayController.install(it) }
        }
    }

    /** Builder-DSL variant — preferred for multi-option configuration. */
    fun init(
        context: Context,
        block: KourierConfig.Builder.() -> Unit
    ) {
        init(context, KourierConfig.Builder().apply(block).build())
    }

    /** Programmatically opens the Kourier debugger UI. */
    fun showUI() = KourierUI.show()

    /** Programmatically closes the Kourier debugger UI. */
    fun hideUI() = KourierUI.hide()
}
